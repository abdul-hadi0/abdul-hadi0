# Dubai Car Wash React Landing Page

Steps to Run Locally
1. Install Node.js
2. npm install
3. npm run dev

Deploy on Vercel
1. Upload folder to Vercel

EmailJS Setup
Replace IDs in src/App.jsx